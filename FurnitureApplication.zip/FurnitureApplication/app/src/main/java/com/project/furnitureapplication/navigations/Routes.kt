package com.project.furnitureapplication.navigations

object Routes {
    var check_out_screen = "Check"
    var home_screens = "Home"
    var LoginScreen = "Login"
    var product_detail_screen = "Product"
}